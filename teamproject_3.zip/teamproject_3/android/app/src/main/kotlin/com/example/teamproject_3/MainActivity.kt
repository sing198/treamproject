package com.example.teamproject_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
